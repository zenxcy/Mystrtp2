package com.mystsmp.core;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickCallback;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** Lahat ng dialog UI ng plugin: /rtp at /rtpq. Purple theme. */
public final class Dialogs {

    static final TextColor PURPLE = TextColor.color(0xFFFFFF);
    static final TextColor LIGHT = TextColor.color(0xFFFFFF);

    private final MystSMPCore plugin;
    private final QueueManager queues;
    private final RtpService rtp;

    public Dialogs(MystSMPCore plugin, QueueManager queues, RtpService rtp) {
        this.plugin = plugin;
        this.queues = queues;
        this.rtp = rtp;
    }

    // ------------------------------------------------------------------ /rtp

    public void openRtp(Player player) {
        List<ActionButton> buttons = new ArrayList<>();
        buttons.add(worldButton("Overworld", "block/grass_block_side", null, World.Environment.NORMAL, false));
        buttons.add(worldButton("Nether", "block/netherrack", null, World.Environment.NETHER, false));
        buttons.add(worldButton("End", "block/end_stone", null, World.Environment.THE_END, false));
        buttons.add(button(
                label("item/iron_sword", Component.text("RTP Queue", PURPLE)),
                Component.text("Mag-RTP kasama ang isa pang player", LIGHT),
                150,
                this::openQueue));

        show(player,
                Msg.parse(plugin.getConfig().getString("dialogs.title-rtp", "<#a855f7>Random Teleport")),
                Msg.parse(plugin.getConfig().getString("dialogs.body-rtp", "Pick a world to randomly teleport")),
                buttons);
    }

    // ------------------------------------------------------------------ /rtpq

    public void openQueue(Player player) {
        List<ActionButton> buttons = new ArrayList<>();
        buttons.add(worldButton("Overworld", "block/grass_block_side", null, World.Environment.NORMAL, true));
        buttons.add(worldButton("Nether", "block/netherrack", null, World.Environment.NETHER, true));
        buttons.add(worldButton("End", "block/end_stone", null, World.Environment.THE_END, true));

        buttons.add(button(
                label("item/barrier", Component.text("Leave Queue", NamedTextColor.RED)),
                null,
                150,
                p -> {
                    queues.leave(p);
                    openQueue(p);
                }));
        buttons.add(button(
                label("item/arrow", Component.text("Back", PURPLE)),
                null,
                150,
                this::openRtp));

        show(player,
                Msg.parse(plugin.getConfig().getString("dialogs.title-queue", "<#a855f7>RTP Queue")),
                Msg.parse(plugin.getConfig().getString("dialogs.body-queue", "Join a queue")),
                buttons);
    }

    // ------------------------------------------------------------------ helpers

    private ActionButton worldButton(String name, String sprite, Component tooltip,
                                     World.Environment env, boolean queueMode) {
        Component text = Component.text(name, PURPLE);
        if (queueMode) {
            text = text.append(Component.text(" (", NamedTextColor.GRAY))
                    .append(Component.text(queues.size(env), LIGHT))
                    .append(Component.text("/" + queues.required() + ")", NamedTextColor.GRAY));
        }
        return button(label(sprite, text), tooltip, 150, p -> {
            if (queueMode) {
                queues.join(p, env);
                openQueue(p); // i-refresh ang bilang
            } else {
                rtp.rtp(p, env);
            }
        });
    }

    /** Icon + pangalan. */
    private Component label(String sprite, Component text) {
        if (!plugin.getConfig().getBoolean("dialogs.show-icons", true)) {
            return text;
        }
        return Icons.sprite(sprite).append(Component.space()).append(text);
    }

    private ActionButton button(Component label, Component tooltip, int width, Consumer<Player> onClick) {
        DialogAction action = DialogAction.customClick((view, audience) -> {
            if (audience instanceof Player p) {
                // siguradong main thread
                Bukkit.getScheduler().runTask(plugin, () -> onClick.accept(p));
            }
        }, ClickCallback.Options.builder()
                .uses(ClickCallback.UNLIMITED_USES)
                .lifetime(Duration.ofMinutes(10))
                .build());
        return ActionButton.create(label, tooltip, width, action);
    }

    private void show(Player player, Component title, Component body, List<ActionButton> buttons) {
        ActionButton close = ActionButton.create(
                Component.text("Close", NamedTextColor.WHITE), null, 200, null);

        Dialog dialog = Dialog.create(factory -> factory.empty()
                .base(DialogBase.builder(title)
                        .canCloseWithEscape(true)
                        .body(List.of(DialogBody.plainMessage(body)))
                        .build())
                .type(DialogType.multiAction(buttons, close, 3)));

        player.showDialog(dialog);
    }
}
