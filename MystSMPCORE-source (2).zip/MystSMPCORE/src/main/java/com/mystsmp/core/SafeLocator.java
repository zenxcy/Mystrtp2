package com.mystsmp.core;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.util.Vector;

import java.util.EnumSet;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;

/**
 * Naghahanap ng SAFE na lugar: solid ang tinatapakan, 2 blocks na libre sa taas,
 * walang lava/tubig/apoy/cactus/etc, at nasa loob ng world border.
 * Lahat ng block check ay nasa main thread; async lang ang chunk loading.
 */
public final class SafeLocator {

    private static final Set<Material> UNSAFE = EnumSet.of(
            Material.LAVA, Material.WATER, Material.FIRE, Material.SOUL_FIRE,
            Material.CACTUS, Material.MAGMA_BLOCK, Material.CAMPFIRE, Material.SOUL_CAMPFIRE,
            Material.SWEET_BERRY_BUSH, Material.POWDER_SNOW, Material.COBWEB,
            Material.WITHER_ROSE, Material.POINTED_DRIPSTONE, Material.TNT,
            Material.NETHER_PORTAL, Material.END_PORTAL, Material.END_GATEWAY,
            Material.BEDROCK, Material.BUBBLE_COLUMN
    );

    private final MystSMPCore plugin;

    public SafeLocator(MystSMPCore plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------- worlds

    public static String keyOf(World.Environment env) {
        return switch (env) {
            case NORMAL -> "overworld";
            case NETHER -> "nether";
            case THE_END -> "end";
            default -> null;
        };
    }

    public World worldFor(World.Environment env) {
        String key = keyOf(env);
        if (key == null) {
            return null;
        }
        String name = plugin.getConfig().getString("rtp.worlds." + key + ".name");
        if (name != null) {
            World w = Bukkit.getWorld(name);
            if (w != null) {
                return w;
            }
        }
        for (World w : Bukkit.getWorlds()) {
            if (w.getEnvironment() == env) {
                return w;
            }
        }
        return null;
    }

    // ---------------------------------------------------------------- random single

    public void findRandom(World world, Consumer<Location> callback) {
        int attempts = plugin.getConfig().getInt("rtp.max-attempts", 40);
        attempt(world, attempts, callback);
    }

    private void attempt(World world, int left, Consumer<Location> callback) {
        if (left <= 0) {
            callback.accept(null);
            return;
        }
        int[] xz = randomColumn(world, 0);
        locate(world, xz[0], xz[1]).thenAccept(loc -> {
            if (loc != null) {
                callback.accept(loc);
            } else {
                attempt(world, left - 1, callback);
            }
        });
    }

    // ---------------------------------------------------------------- opposite pair

    /** Dalawang safe na lugar sa magkabilang dulo ng isang random na gitna, nakaharap sa isa't isa. */
    public void findPair(World world, Consumer<Location[]> callback) {
        int attempts = plugin.getConfig().getInt("rtp.max-attempts", 40);
        pairAttempt(world, attempts, callback);
    }

    private void pairAttempt(World world, int left, Consumer<Location[]> callback) {
        if (left <= 0) {
            callback.accept(null);
            return;
        }
        int dist = Math.max(10, plugin.getConfig().getInt("queue.opposite-distance", 75));
        int[] c = randomColumn(world, dist);
        double angle = ThreadLocalRandom.current().nextDouble(0, Math.PI * 2);
        int dx = (int) Math.round(Math.cos(angle) * dist);
        int dz = (int) Math.round(Math.sin(angle) * dist);

        locate(world, c[0] + dx, c[1] + dz).thenAccept(a -> {
            if (a == null) {
                pairAttempt(world, left - 1, callback);
                return;
            }
            locate(world, c[0] - dx, c[1] - dz).thenAccept(b -> {
                if (b == null) {
                    pairAttempt(world, left - 1, callback);
                    return;
                }
                face(a, c[0] + 0.5, c[1] + 0.5);
                face(b, c[0] + 0.5, c[1] + 0.5);
                callback.accept(new Location[]{a, b});
            });
        });
    }

    private void face(Location loc, double tx, double tz) {
        Vector dir = new Vector(tx - loc.getX(), 0, tz - loc.getZ());
        if (dir.lengthSquared() > 0.0001) {
            loc.setDirection(dir);
        }
    }

    // ---------------------------------------------------------------- core

    private int[] randomColumn(World world, int margin) {
        String key = keyOf(world.getEnvironment());
        String base = "rtp.worlds." + (key == null ? "overworld" : key);
        FileConfiguration cfg = plugin.getConfig();
        int cx = cfg.getInt(base + ".center-x", 0);
        int cz = cfg.getInt(base + ".center-z", 0);
        double min = cfg.getInt(base + ".min-radius", 500);
        double max = cfg.getInt(base + ".max-radius", 5000);

        double borderHalf = world.getWorldBorder().getSize() / 2.0 - 16 - margin;
        max = Math.min(max, borderHalf);
        if (max < 1) {
            max = 1;
        }
        if (min >= max) {
            min = 0;
        }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double radius = Math.sqrt(r.nextDouble() * (max * max - min * min) + min * min);
        double angle = r.nextDouble(0, Math.PI * 2);
        int x = cx + (int) Math.round(Math.cos(angle) * radius);
        int z = cz + (int) Math.round(Math.sin(angle) * radius);
        return new int[]{x, z};
    }

    /** Naglo-load ng chunk (async) tapos chine-check sa main thread kung safe ang column na ito. */
    private CompletableFuture<Location> locate(World world, int x, int z) {
        CompletableFuture<Location> future = new CompletableFuture<>();
        try {
            world.getChunkAtAsync(x >> 4, z >> 4).whenComplete((chunk, error) -> {
                if (error != null || chunk == null) {
                    future.complete(null);
                    return;
                }
                Bukkit.getScheduler().runTask(plugin, () -> {
                    try {
                        future.complete(check(world, x, z));
                    } catch (Throwable t) {
                        future.complete(null);
                    }
                });
            });
        } catch (Throwable t) {
            future.complete(null);
        }
        return future;
    }

    private Location check(World world, int x, int z) {
        switch (world.getEnvironment()) {
            case NETHER -> {
                // Nasa ilalim ng bedrock roof (y 127). Mula taas pababa hanap ng butas na may sahig.
                int top = Math.min(world.getMaxHeight() - 1, 120);
                int bottom = Math.max(world.getMinHeight() + 1, 33);
                for (int y = top; y >= bottom; y--) {
                    Location loc = validate(world, x, y, z);
                    if (loc != null) {
                        return loc;
                    }
                }
                return null;
            }
            case THE_END -> {
                int y = world.getHighestBlockYAt(x, z);
                if (y <= world.getMinHeight() + 1) {
                    return null; // void
                }
                return validate(world, x, y, z);
            }
            default -> {
                int y = world.getHighestBlockYAt(x, z);
                return validate(world, x, y, z);
            }
        }
    }

    /** y = block na tatapakan. Ibabalik ang lokasyon sa ibabaw nito kung safe. */
    private Location validate(World world, int x, int y, int z) {
        if (y < world.getMinHeight() + 1 || y + 2 >= world.getMaxHeight()) {
            return null;
        }
        Block ground = world.getBlockAt(x, y, z);
        Block feet = world.getBlockAt(x, y + 1, z);
        Block head = world.getBlockAt(x, y + 2, z);

        Material g = ground.getType();
        if (!g.isSolid() || UNSAFE.contains(g) || Tag.LEAVES.isTagged(g)) {
            return null;
        }
        if (!isFree(feet) || !isFree(head)) {
            return null;
        }
        Location loc = new Location(world, x + 0.5, y + 1, z + 0.5);
        if (!world.getWorldBorder().isInside(loc)) {
            return null;
        }
        return loc;
    }

    private boolean isFree(Block block) {
        Material m = block.getType();
        return block.isPassable() && !block.isLiquid() && !UNSAFE.contains(m);
    }
}
