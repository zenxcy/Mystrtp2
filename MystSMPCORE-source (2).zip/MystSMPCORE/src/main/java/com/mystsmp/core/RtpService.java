package com.mystsmp.core;

import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class RtpService {

    private final MystSMPCore plugin;
    private final Msg msg;
    private final SafeLocator locator;

    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Set<UUID> searching = new HashSet<>();

    public RtpService(MystSMPCore plugin, Msg msg, SafeLocator locator) {
        this.plugin = plugin;
        this.msg = msg;
        this.locator = locator;
    }

    public static String displayName(World.Environment env) {
        return switch (env) {
            case NORMAL -> "Overworld";
            case NETHER -> "Nether";
            case THE_END -> "End";
            default -> "Unknown";
        };
    }

    public void rtp(Player player, World.Environment env) {
        UUID id = player.getUniqueId();

        World world = locator.worldFor(env);
        if (world == null) {
            msg.send(player, "world-missing", Placeholder.unparsed("world", displayName(env)));
            return;
        }

        int cooldown = plugin.getConfig().getInt("rtp.cooldown-seconds", 10);
        if (cooldown > 0 && !player.hasPermission("mystsmp.rtp.bypass")) {
            long last = cooldowns.getOrDefault(id, 0L);
            long left = (last + cooldown * 1000L - System.currentTimeMillis() + 999) / 1000;
            if (left > 0) {
                msg.send(player, "cooldown", Placeholder.unparsed("seconds", String.valueOf(left)));
                return;
            }
        }

        if (!searching.add(id)) {
            msg.send(player, "busy");
            return;
        }

        int seconds = plugin.getConfig().getInt("rtp.countdown-seconds", 5);
        boolean cancelOnMove = plugin.getConfig().getBoolean("rtp.cancel-on-move", true);

        Countdown.run(plugin, msg, List.of(player), seconds, cancelOnMove,
                () -> search(player, world, env),
                () -> searching.remove(id));
    }

    private void search(Player player, World world, World.Environment env) {
        UUID id = player.getUniqueId();
        if (!player.isOnline()) {
            searching.remove(id);
            return;
        }
        msg.send(player, "searching", Placeholder.unparsed("world", displayName(env)));

        locator.findRandom(world, loc -> {
            searching.remove(id);
            if (!player.isOnline()) {
                return;
            }
            if (loc == null) {
                msg.send(player, "failed");
                return;
            }
            player.teleportAsync(loc).thenAccept(ok -> {
                if (!ok) {
                    msg.send(player, "failed");
                    return;
                }
                cooldowns.put(id, System.currentTimeMillis());
                sendArrival(player, loc, env);
            });
        });
    }

    private void sendArrival(Player player, Location loc, World.Environment env) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) {
                return;
            }
            msg.send(player, "success",
                    Placeholder.unparsed("x", String.valueOf(loc.getBlockX())),
                    Placeholder.unparsed("y", String.valueOf(loc.getBlockY())),
                    Placeholder.unparsed("z", String.valueOf(loc.getBlockZ())),
                    Placeholder.unparsed("world", displayName(env)));
            player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.8f, 1.2f);
        });
    }
}
