package com.mystsmp.core;

import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * RTP queue: kapag sapat na ang players sa isang world queue, ite-teleport sila
 * sa magkabilang dulo (opposite position) ng isang safe na lugar.
 */
public final class QueueManager {

    private final MystSMPCore plugin;
    private final Msg msg;
    private final SafeLocator locator;

    private final Map<World.Environment, Deque<UUID>> queues = new EnumMap<>(World.Environment.class);

    public QueueManager(MystSMPCore plugin, Msg msg, SafeLocator locator) {
        this.plugin = plugin;
        this.msg = msg;
        this.locator = locator;
        for (World.Environment env : new World.Environment[]{
                World.Environment.NORMAL, World.Environment.NETHER, World.Environment.THE_END}) {
            queues.put(env, new ArrayDeque<>());
        }
    }

    public int required() {
        return Math.max(2, plugin.getConfig().getInt("queue.required-players", 2));
    }

    public int size(World.Environment env) {
        Deque<UUID> q = queues.get(env);
        return q == null ? 0 : q.size();
    }

    public World.Environment queueOf(UUID id) {
        for (Map.Entry<World.Environment, Deque<UUID>> e : queues.entrySet()) {
            if (e.getValue().contains(id)) {
                return e.getKey();
            }
        }
        return null;
    }

    public void join(Player player, World.Environment env) {
        World world = locator.worldFor(env);
        if (world == null) {
            msg.send(player, "world-missing", Placeholder.unparsed("world", RtpService.displayName(env)));
            return;
        }

        UUID id = player.getUniqueId();
        leaveSilently(id);

        Deque<UUID> q = queues.get(env);
        q.addLast(id);

        msg.send(player, "queue-joined",
                Placeholder.unparsed("world", RtpService.displayName(env)),
                Placeholder.unparsed("count", String.valueOf(q.size())),
                Placeholder.unparsed("needed", String.valueOf(required())));
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 0.8f, 1.4f);

        tryMatch(env, world);
    }

    /** @return true kung may inalisan. */
    public boolean leave(Player player) {
        boolean was = leaveSilently(player.getUniqueId());
        msg.send(player, was ? "queue-left" : "queue-not-in");
        return was;
    }

    public boolean leaveSilently(UUID id) {
        boolean removed = false;
        for (Deque<UUID> q : queues.values()) {
            removed |= q.remove(id);
        }
        return removed;
    }

    public void clear() {
        queues.values().forEach(Deque::clear);
    }

    // ------------------------------------------------------------------

    private void tryMatch(World.Environment env, World world) {
        Deque<UUID> q = queues.get(env);
        if (q.size() < 2) {
            return;
        }

        // Kunin ang unang dalawang online na players.
        Player a = pollOnline(q);
        Player b = pollOnline(q);
        if (a == null) {
            return;
        }
        if (b == null) {
            q.addFirst(a.getUniqueId());
            return;
        }

        msg.send(a, "queue-matched", Placeholder.unparsed("player", b.getName()));
        msg.send(b, "queue-matched", Placeholder.unparsed("player", a.getName()));

        int seconds = plugin.getConfig().getInt("queue.countdown-seconds", 5);

        Countdown.run(plugin, msg, List.of(a, b), seconds, false,
                () -> locator.findPair(world, pair -> {
                    if (pair == null) {
                        msg.send(a, "queue-failed");
                        msg.send(b, "queue-failed");
                        return;
                    }
                    if (!a.isOnline() || !b.isOnline()) {
                        requeueOnline(env, a, b);
                        return;
                    }
                    teleport(a, pair[0], b);
                    teleport(b, pair[1], a);
                }),
                () -> requeueOnline(env, a, b));
    }

    /** Kapag may umalis habang nagbibilang, ibalik ang natirang online na player sa queue. */
    private void requeueOnline(World.Environment env, Player a, Player b) {
        for (Player p : new Player[]{a, b}) {
            if (p.isOnline()) {
                queues.get(env).addFirst(p.getUniqueId());
                msg.send(p, "queue-partner-left");
            }
        }
    }

    private Player pollOnline(Deque<UUID> q) {
        UUID id;
        while ((id = q.pollFirst()) != null) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && p.isOnline()) {
                return p;
            }
        }
        return null;
    }

    private void teleport(Player player, Location loc, Player partner) {
        player.teleportAsync(loc).thenAccept(ok -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) {
                return;
            }
            if (!ok) {
                msg.send(player, "queue-failed");
                return;
            }
            msg.send(player, "queue-teleported", Placeholder.unparsed("player", partner.getName()));
            player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.8f, 1.2f);
        }));
    }
}
