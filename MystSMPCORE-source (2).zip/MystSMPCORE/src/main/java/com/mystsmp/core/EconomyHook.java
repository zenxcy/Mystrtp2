package com.mystsmp.core;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.lang.reflect.Method;

/**
 * Vault economy, ginagamit sa pamamagitan ng reflection para hindi na kailangan
 * ng Vault sa pag-build. Kailangan lang may Vault + economy plugin sa server.
 */
public final class EconomyHook {

    private Object provider;
    private Method has;
    private Method withdraw;
    private Method deposit;

    @SuppressWarnings({"unchecked", "rawtypes"})
    public boolean available() {
        if (provider != null) {
            return true;
        }
        try {
            Plugin vault = Bukkit.getPluginManager().getPlugin("Vault");
            if (vault == null) {
                return false;
            }
            Class<?> ecoClass = Class.forName("net.milkbowl.vault.economy.Economy", true,
                    vault.getClass().getClassLoader());
            RegisteredServiceProvider rsp = Bukkit.getServicesManager().getRegistration((Class) ecoClass);
            if (rsp == null) {
                return false;
            }
            Object p = rsp.getProvider();
            has = ecoClass.getMethod("has", OfflinePlayer.class, double.class);
            withdraw = ecoClass.getMethod("withdrawPlayer", OfflinePlayer.class, double.class);
            deposit = ecoClass.getMethod("depositPlayer", OfflinePlayer.class, double.class);
            provider = p;
            return true;
        } catch (Throwable t) {
            provider = null;
            return false;
        }
    }

    public boolean has(OfflinePlayer player, double amount) {
        if (!available()) {
            return false;
        }
        try {
            return (boolean) has.invoke(provider, player, amount);
        } catch (Throwable t) {
            return false;
        }
    }

    public boolean withdraw(OfflinePlayer player, double amount) {
        return transact(withdraw, player, amount);
    }

    public boolean deposit(OfflinePlayer player, double amount) {
        return transact(deposit, player, amount);
    }

    private boolean transact(Method method, OfflinePlayer player, double amount) {
        if (!available()) {
            return false;
        }
        try {
            Object response = method.invoke(provider, player, amount);
            Method ok = response.getClass().getMethod("transactionSuccess");
            return (boolean) ok.invoke(response);
        } catch (Throwable t) {
            return false;
        }
    }
}
