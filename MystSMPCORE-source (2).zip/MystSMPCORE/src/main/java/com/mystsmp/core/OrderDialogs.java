package com.mystsmp.core;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickCallback;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/** Lahat ng dialog ng /order: menu, browse, new order, your orders, search, deliver. */
public final class OrderDialogs {

    private static final TextColor WHITE = NamedTextColor.WHITE;
    private static final TextColor GRAY = NamedTextColor.GRAY;
    private static final TextColor GREEN = NamedTextColor.GREEN;
    private static final TextColor RED = NamedTextColor.RED;

    private final MystSMPCore plugin;
    private final Msg msg;
    private final OrderManager orders;
    private final EconomyHook eco;
    private final DeliveryService delivery;

    public OrderDialogs(MystSMPCore plugin, Msg msg, OrderManager orders, EconomyHook eco, DeliveryService delivery) {
        this.plugin = plugin;
        this.msg = msg;
        this.orders = orders;
        this.eco = eco;
        this.delivery = delivery;
    }

    // ================================================================== MENU

    public void openMenu(Player player) {
        int max = plugin.getConfig().getInt("orders.max-per-player", 1);
        int active = orders.activeCount(player.getUniqueId());

        List<ActionButton> buttons = new ArrayList<>();
        buttons.add(button("Browse Orders", GREEN, 150, p -> openBrowse(p, 0, null)));
        buttons.add(button("New Order", GREEN, 150, this::openNewOrder));
        buttons.add(button("Your Orders", GREEN, 150, this::openYourOrders));
        buttons.add(button("Search", GREEN, 150, this::openSearch));

        show(player, "Orders",
                List.of(text("Request items and get paid when other players deliver them."),
                        gray("Active orders: " + active + "/" + max)),
                List.of(), buttons, 2);
    }

    // ================================================================== BROWSE

    public void openBrowse(Player player, int page, String filter) {
        List<Order> list = orders.active(filter);
        int size = Math.max(5, plugin.getConfig().getInt("orders.page-size", 15));
        int pages = Math.max(1, (list.size() + size - 1) / size);
        int current = Math.max(0, Math.min(page, pages - 1));

        List<ActionButton> buttons = new ArrayList<>();
        int from = current * size;
        int to = Math.min(list.size(), from + size);
        for (int i = from; i < to; i++) {
            Order o = list.get(i);
            buttons.add(button(describe(o), WHITE, 300, p -> openDeliver(p, o.id)));
        }
        if (current > 0) {
            buttons.add(button("Previous Page", WHITE, 300, p -> openBrowse(p, current - 1, filter)));
        }
        if (current < pages - 1) {
            buttons.add(button("Next Page", WHITE, 300, p -> openBrowse(p, current + 1, filter)));
        }
        buttons.add(button("Back", WHITE, 300, this::openMenu));

        List<Component> body = new ArrayList<>();
        body.add(text(list.isEmpty() ? "No orders found." : "Select an order for details."));
        if (pages > 1) {
            body.add(gray("Page " + (current + 1) + "/" + pages));
        }
        show(player, "Browse Orders", body, List.of(), buttons, 1);
    }

    // ================================================================== DELIVER

    public void openDeliver(Player player, int orderId) {
        Order order = orders.find(orderId);
        if (order == null || order.remaining() <= 0) {
            msg.send(player, "order-gone");
            openBrowse(player, 0, null);
            return;
        }

        DialogInput amount = DialogInput.text("amount", text("Amount")).initial("1").maxLength(15).build();

        List<ActionButton> buttons = new ArrayList<>();
        buttons.add(inputButton("Deliver Items", GREEN, 200, List.of("amount"),
                (p, v) -> handleDeliver(p, orderId, v.get("amount"))));
        buttons.add(button("Back", WHITE, 200, p -> openBrowse(p, 0, null)));

        show(player, "Deliver Order",
                List.of(text(describe(order)), text("Choose the amount to deliver.")),
                List.of(amount), buttons, 1);
    }

    private void handleDeliver(Player player, int orderId, String rawAmount) {
        if (!eco.available()) {
            msg.send(player, "order-no-economy");
            return;
        }
        Order order = orders.find(orderId);
        if (order == null || order.remaining() <= 0) {
            msg.send(player, "order-gone");
            return;
        }
        if (order.owner.equals(player.getUniqueId())) {
            msg.send(player, "order-own");
            return;
        }
        Double parsed = Fmt.parseNumber(rawAmount);
        if (parsed == null || parsed < 1) {
            msg.send(player, "order-invalid-amount");
            openDeliver(player, orderId);
            return;
        }
        long amount = (long) Math.min(Math.floor(parsed), (double) order.remaining());
        delivery.openChest(player, order, amount);
    }

    // ================================================================== SEARCH

    public void openSearch(Player player) {
        DialogInput item = DialogInput.text("item", text("Item name")).initial("").maxLength(40).build();

        List<ActionButton> buttons = new ArrayList<>();
        buttons.add(inputButton("Search", GREEN, 200, List.of("item"),
                (p, v) -> openBrowse(p, 0, v.get("item"))));
        buttons.add(button("Back", WHITE, 200, this::openMenu));

        show(player, "Search",
                List.of(text("Type the name of the item you are looking for.")),
                List.of(item), buttons, 1);
    }

    // ================================================================== NEW ORDER

    public void openNewOrder(Player player) {
        DialogInput item = DialogInput.text("item", text("Item")).initial("").maxLength(40).build();
        DialogInput amount = DialogInput.text("amount", text("Amount")).initial("64").maxLength(15).build();
        DialogInput price = DialogInput.text("price", text("Price per item")).initial("1").maxLength(15).build();

        List<ActionButton> buttons = new ArrayList<>();
        buttons.add(inputButton("Confirm", GREEN, 200, List.of("item", "amount", "price"),
                this::handleConfirm));

        show(player, "New Order",
                List.of(text("Choose the item, the amount and the price per item."),
                        gray("Amount: 1 to unlimited, price: 1 to unlimited")),
                List.of(item, amount, price), buttons, 1);
    }

    private void handleConfirm(Player player, Map<String, String> v) {
        if (!eco.available()) {
            msg.send(player, "order-no-economy");
            return;
        }

        int max = plugin.getConfig().getInt("orders.max-per-player", 1);
        if (!player.hasPermission("mystsmp.order.unlimited")
                && orders.activeCount(player.getUniqueId()) >= max) {
            msg.send(player, "order-limit", Placeholder.unparsed("max", String.valueOf(max)));
            return;
        }

        Material material = Fmt.parseItem(v.get("item"));
        if (material == null) {
            msg.send(player, "order-invalid-item");
            openNewOrder(player);
            return;
        }

        Double a = Fmt.parseNumber(v.get("amount"));
        double maxAmount = plugin.getConfig().getDouble("orders.max-amount", 1_000_000_000d);
        if (a == null || a < 1 || a > maxAmount) {
            msg.send(player, "order-invalid-amount");
            openNewOrder(player);
            return;
        }
        long amount = (long) Math.floor(a);

        Double pr = Fmt.parseNumber(v.get("price"));
        double minPrice = plugin.getConfig().getDouble("orders.min-price", 1);
        if (pr == null || pr < minPrice) {
            msg.send(player, "order-invalid-price", Placeholder.unparsed("min", Fmt.price(minPrice)));
            openNewOrder(player);
            return;
        }

        double total = amount * pr;
        if (Double.isInfinite(total) || total > 1e15) {
            msg.send(player, "order-invalid-amount");
            openNewOrder(player);
            return;
        }

        if (!eco.has(player, total) || !eco.withdraw(player, total)) {
            msg.send(player, "order-no-money", Placeholder.unparsed("money", Fmt.money(total)));
            return;
        }

        Order order = orders.create(player.getUniqueId(), player.getName(), material, amount, pr);
        msg.send(player, "order-created",
                Placeholder.unparsed("amount", String.valueOf(order.requested)),
                Placeholder.unparsed("item", Fmt.name(material)),
                Placeholder.unparsed("price", Fmt.price(pr)),
                Placeholder.unparsed("money", Fmt.money(total)));
    }

    // ================================================================== YOUR ORDERS

    public void openYourOrders(Player player) {
        List<Order> mine = orders.ownedBy(player.getUniqueId());

        List<ActionButton> buttons = new ArrayList<>();
        for (Order o : mine) {
            buttons.add(button(describe(o), WHITE, 300, p -> openManage(p, o.id)));
        }
        buttons.add(button("Back", WHITE, 300, this::openMenu));

        show(player, "Your Orders",
                List.of(text(mine.isEmpty() ? "No orders found." : "Select an order to manage.")),
                List.of(), buttons, 1);
    }

    public void openManage(Player player, int orderId) {
        Order order = orders.find(orderId);
        if (order == null || !order.owner.equals(player.getUniqueId())) {
            msg.send(player, "order-gone");
            openYourOrders(player);
            return;
        }

        List<ActionButton> buttons = new ArrayList<>();
        if (order.uncollected() > 0) {
            buttons.add(button("Collect Items (" + order.uncollected() + ")", GREEN, 200, p -> {
                collect(p, orderId);
                openManageIfExists(p, orderId);
            }));
        }
        if (order.remaining() > 0) {
            buttons.add(button("Cancel Order", RED, 200, p -> {
                cancel(p, orderId);
                openYourOrders(p);
            }));
        }
        buttons.add(button("Back", WHITE, 200, this::openYourOrders));

        show(player, "Manage Order",
                List.of(text(describe(order)),
                        gray("To collect: " + order.uncollected() + ", remaining: " + order.remaining())),
                List.of(), buttons, 1);
    }

    private void openManageIfExists(Player player, int orderId) {
        if (orders.find(orderId) != null) {
            openManage(player, orderId);
        } else {
            openYourOrders(player);
        }
    }

    /** Kunin ang na-deliver na items. Ibabalik ang ilang naibigay. */
    private long giveItems(Player player, Order order, long amount) {
        long given = 0;
        long left = amount;
        int stack = Math.max(1, order.material.getMaxStackSize());
        while (left > 0) {
            int n = (int) Math.min(stack, left);
            Map<Integer, ItemStack> rem = player.getInventory().addItem(new ItemStack(order.material, n));
            if (!rem.isEmpty()) {
                int notAdded = rem.values().iterator().next().getAmount();
                given += n - notAdded;
                break;
            }
            given += n;
            left -= n;
        }
        return given;
    }

    private void collect(Player player, int orderId) {
        Order order = orders.find(orderId);
        if (order == null || !order.owner.equals(player.getUniqueId())) {
            return;
        }
        long available = order.uncollected();
        if (available <= 0) {
            msg.send(player, "order-nothing-to-collect");
            return;
        }
        long given = giveItems(player, order, available);
        order.collected += given;
        orders.cleanup(order);

        if (given <= 0) {
            msg.send(player, "order-inventory-full");
            return;
        }
        msg.send(player, "order-collected",
                Placeholder.unparsed("amount", String.valueOf(given)),
                Placeholder.unparsed("item", Fmt.name(order.material)));
        if (given < available) {
            msg.send(player, "order-inventory-full");
        }
    }

    private void cancel(Player player, int orderId) {
        Order order = orders.find(orderId);
        if (order == null || !order.owner.equals(player.getUniqueId()) || order.remaining() <= 0) {
            return;
        }
        double refund = order.remaining() * order.price;
        if (!eco.deposit(player, refund)) {
            msg.send(player, "order-no-economy");
            return;
        }
        order.requested = order.delivered; // wala nang natitira
        msg.send(player, "order-cancelled", Placeholder.unparsed("money", Fmt.money(refund)));

        // Ibigay na rin ang mga na-deliver na hindi pa nakukuha.
        if (order.uncollected() > 0) {
            long given = giveItems(player, order, order.uncollected());
            order.collected += given;
            if (given > 0) {
                msg.send(player, "order-collected",
                        Placeholder.unparsed("amount", String.valueOf(given)),
                        Placeholder.unparsed("item", Fmt.name(order.material)));
            }
            if (order.uncollected() > 0) {
                msg.send(player, "order-inventory-full");
            }
        }
        orders.cleanup(order);
    }

    // ================================================================== helpers

    private String describe(Order o) {
        return Fmt.name(o.material) + " | requested " + o.requested
                + ", delivered " + o.delivered + ", price " + Fmt.price(o.price);
    }

    private Component text(String s) {
        return Component.text(s, WHITE);
    }

    private Component gray(String s) {
        return Component.text(s, GRAY);
    }

    private ActionButton button(String label, TextColor color, int width, Consumer<Player> click) {
        return inputButton(label, color, width, List.of(), (p, v) -> click.accept(p));
    }

    /** Button na binabasa muna ang input fields bago tumakbo sa main thread. */
    private ActionButton inputButton(String label, TextColor color, int width, List<String> keys,
                                     BiConsumer<Player, Map<String, String>> click) {
        DialogAction action = DialogAction.customClick((view, audience) -> {
            Map<String, String> values = new HashMap<>();
            for (String key : keys) {
                String value = view.getText(key);
                values.put(key, value == null ? "" : value);
            }
            if (audience instanceof Player p) {
                Bukkit.getScheduler().runTask(plugin, () -> click.accept(p, values));
            }
        }, ClickCallback.Options.builder()
                .uses(ClickCallback.UNLIMITED_USES)
                .lifetime(Duration.ofMinutes(10))
                .build());
        return ActionButton.create(Component.text(label, color), null, width, action);
    }

    private void show(Player player, String title, List<Component> body, List<DialogInput> inputs,
                      List<ActionButton> buttons, int columns) {
        List<DialogBody> bodies = new ArrayList<>();
        for (Component c : body) {
            bodies.add(DialogBody.plainMessage(c));
        }
        ActionButton close = ActionButton.create(Component.text("Close", WHITE), null, 200, null);

        Dialog dialog = Dialog.create(factory -> factory.empty()
                .base(DialogBase.builder(Component.text(title, WHITE))
                        .canCloseWithEscape(true)
                        .body(bodies)
                        .inputs(inputs)
                        .build())
                .type(DialogType.multiAction(buttons, close, columns)));

        player.showDialog(dialog);
    }
}
