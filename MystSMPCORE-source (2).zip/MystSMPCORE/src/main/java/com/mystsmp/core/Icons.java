package com.mystsmp.core;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.object.ObjectContents;

/**
 * Item/block icon sa loob ng text (Minecraft 1.21.9+ "object" component).
 * Kapag hindi supported ng server version, walang icon na ilalagay (hindi mag-eerror).
 */
final class Icons {

    private Icons() {
    }

    /** @param sprite hal. "block/grass_block_side" o "item/iron_sword" (galing sa blocks atlas) */
    static Component sprite(String sprite) {
        try {
            return Component.object(ObjectContents.sprite(Key.key("minecraft", "blocks"), Key.key("minecraft", sprite)));
        } catch (Throwable ignored) {
            return Component.empty();
        }
    }
}
