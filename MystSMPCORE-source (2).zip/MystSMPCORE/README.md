# MystSMPCORE

Core plugin ng MysticSMP (Paper 1.21.9+, Java 21). Purple theme.

## Commands
| Command | Ginagawa |
|---|---|
| `/rtp` | Dialog na "Random Teleport": Overworld / Nether / End / RTP Queue |
| `/rtp <overworld\|nether\|end>` | Diretso RTP, walang dialog |
| `/rtpq` | Dialog na "RTP Queue" (may bilang na x/2) |
| `/rtpqleave` | Umalis sa queue |
| `/mystsmp reload` | I-reload ang config |

Safe teleport: solid ang tinatapakan, 2 blocks na libre sa taas, walang lava/tubig/apoy/cactus/etc., sa loob ng world border.

## Build ng .jar

**Sa PC:** `mvn clean package` -> `target/MystSMPCORE.jar`

**Sa phone (GitHub Actions):**
1. Gumawa ng bagong repo sa github.com, i-upload ang lahat ng laman ng folder na ito (kasama ang `.github` folder).
2. Pumunta sa tab na **Actions**, hintayin matapos ang "Build MystSMPCORE" (mga 1 minuto).
3. Buksan ang run, sa baba sa **Artifacts** i-download ang `MystSMPCORE` (zip na may .jar sa loob).
4. Ilagay ang .jar sa `plugins/` ng server at i-restart.

Kung ibang version ang server mo, palitan ang `paper.version` sa `pom.xml`.
